#include "filipplib.h"

struct Object
    {
    int x, y, z;
    int vx, vy;
    HDC hdc;
    int width, height;
    int paramiterr;

    void draw();
    void physics (int dt);
    void physicsCircle (int dt);
    void control ();
    void run (Object geometry [], int size, int dt);
    void circleParamiter (int dt);
    void paramiter (int dt);



    };

//{ ���������

void game (HDC cube, HDC circle, HDC shadow);

int szX (double x);

int szY (double y);

void timecount (int timeStart);

void health (double hearts);

int measure_distance (Object* circle1, Object* circle2);

void bite_function (Object geometry [], int size, double* hearts);

void set_damage (int radius, double damage, Object* object1, Object* object2, double* hearts);
//}

int main ()
    {
    txCreateWindow (GetSystemMetrics (SM_CXSCREEN) - 15, GetSystemMetrics (SM_CYSCREEN) - 55);

    HDC cube = txLoadImage ("���.BMP");

    HDC circle = txLoadImage ("����.BMP");

    HDC shadow = txLoadImage ("������.BMP");




    game (cube, circle, shadow);

    txDeleteDC (cube);
    txDeleteDC (circle);
    txDeleteDC (shadow);

    }

void game (HDC cube, HDC circle, HDC shadow)
    {

    int dt = 1;

    Object geometry [] = { {szX (50), szY (50), 1, 1, 2,  circle, 81, 76, circleParamiter (dt)},
                           {szX (8),  szY (8),  1, 9, 10, cube,   70, 70, paramiter (dt)},
                           {szX (92), szY (92), 1, 9, 10, cube,   70, 70, paramiter (dt)},
                           {szX (92), szY (8),  1, 9, 10, cube,   70, 70, paramiter (dt)},
                           {szX (8),  szY (92), 1, 9, 10, cube,   70, 70, paramiter (dt)} };





    double hearts = 3;
    int timeStart = GetTickCount ();

    txBegin ();

    while (!GetAsyncKeyState (VK_ESCAPE))
        {

        txClear ();
        txSetFillColor (TX_BLACK);

        txBitBlt (txDC(), 0, 0, 0, 0, shadow, 0, 0);

        int i = 0;
        while (i < sizearr(geometry))
            {
            geometry [i].physics (dt);
            geometry [i].draw ();
            i++;
            }



        bite_function (geometry, sizearr (geometry), &hearts);

        timecount (timeStart);

        health (hearts);

        if (hearts <= -1)
            {
            printf ("break\n");
            break;
            }

        geometry [0].control ();

        txSleep (18);

        }
    }

void Object::draw ()
    {
    alphaBlend (x, y, width, height, hdc, 0, 0, width, height, 1);
    //alphaBlend (x, y, 50, 57, hdc, 0, 0, 50, 57, 1);
    //txAlphaBlend (txDC(), x, y, width, height, hdc, 0, 0);
    }

int szX (double x)
    {
    return x * txGetExtentX()/100;
    }

int szY (double y)
    {
    return y * txGetExtentY()/100;
    }

void Object::physics (int dt)
    {
    x = x + vx * dt;
    y = y + vy * dt;

    if  (x >= txGetExtentX())
        {
        vx = -vx;
        x = txGetExtentX();
        }
    if  (y >= txGetExtentY())
        {
        vy = -vy;
        y = txGetExtentY();
        }
    if (x <= 0)
        {
        vx = -vx;
        x = 0;
        }
    if (y <= 0)
        {
        vy = -vy;
        y = 0;
        }
    }

void Object::physicsCircle (int dt)
    {
    x = x + vx * dt;
    y = y + vy * dt;

    if  (x >= txGetExtentX())
        {
        x = 0;
        }
    if  (y >= txGetExtentY())
        {
        vy = -vy;
        y = txGetExtentY();
        }
    if (x <= 0)
        {
        x = txGetExtentX();
        }
    if (y <= 0)
        {
        vy = -vy;
        y = 0;
        }

    }

void timecount (int timeStart)
    {

    char str [100] = "";
    int time = (GetTickCount () - timeStart)/1000;

    if (time <= 60)
        {
        sprintf (str, "  %d:%d", time/60, time%60);
        }

    if (time >= 60)
        {
        sprintf (str, "  %d:%d", time/60, time%60);

        }

    txSetColor (TX_WHITE);
    txSelectFont ("Arial", 70);
    txTextOut (szX (4), szY (7), str);
    }

void health (double hearts)
    {
    txSelectFont ("SYMBOL", 75);

    int nHearts = 0;
    while (nHearts <= hearts)
        {
        txSetColor (TX_RED);
        txTextOut (szX (7) + 40 * nHearts, szY (95), "�");
        nHearts++;
        }
    }

void Object::control ()
    {
    if (GetAsyncKeyState (VK_LEFT))  vx--;
    if (GetAsyncKeyState (VK_RIGHT)) vx++;
    if (GetAsyncKeyState (VK_UP))    vy--;
    if (GetAsyncKeyState (VK_DOWN))  vy++;
    if (GetAsyncKeyState ('Q'))
        {
        vx = 0;
        vy = 0;
        }
    }

int measure_distance (Object* circle1, Object* circle2)
    {
    int distance = sqrt (((*circle2).x - (*circle1).x) * ((*circle2).x - (*circle1).x) +
                         ((*circle2).y - (*circle1).y) * ((*circle2).y - (*circle1).y));
    return distance;
    }

void bite_function (Object geometry [], int size, double* hearts)
    {
    int i = 1;
    while (i < size)
        {
        set_damage (113, 1.0/3, &geometry[0], &geometry[i],   hearts);

        i++;
        }


    }

void set_damage (int radius, double damage, Object* object1, Object* object2, double* hearts)
    {
    int lengH = measure_distance (object1, object2);

    if (lengH <= radius)
        {
        *hearts -= damage;
        }
    }

void Object::run (Object geometry [], int size, int dt)
    {
    int i = 0;
    while (i < size)
        {
        geometry [i].physics (dt);
        geometry [i].draw ();
        i++;
        }
    }
void Object::paramiter (int dt)
    {
int i = 0;
        while (i < sizearr(geometry))
            {
            geometry [i].physics (dt);
            geometry [i].draw ();
            i++;
            }

         }

void Object::circleParamiter (int dt)
    {
int i = 0;
        while (i < sizearr(geometry))
            {
            geometry [i].physicsCircle (dt);
            geometry [i].draw ();
            i++;
            }

     }



