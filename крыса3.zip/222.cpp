
#include "TXLib.h"

int main()
    {
    txCreateWindow (800, 600);



    return 0;
    }
